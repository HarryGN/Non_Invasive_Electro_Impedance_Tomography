function list = supported_params
   list = {'conductivity'
           'log_conductivity'
           'log10_conductivity'
           'resistivity'
           'log_resistivity'
           'log10_resistivity'
           'movement'};
end